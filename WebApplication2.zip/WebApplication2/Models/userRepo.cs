﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{// userRepo function gets dbContextOptions passed through so that connection string, name of database and user names can be changed
    public class userRepo : DbContext
    {
        public userRepo(DbContextOptions<userRepo> options) : base(options)
        {

        }
        public DbSet<userInfo> userTable { get; set; }
    }
}